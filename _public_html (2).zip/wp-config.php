<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u806441573_migrated' );

/** Database username */
define( 'DB_USER', 'u806441573_migrated' );

/** Database password */
define( 'DB_PASSWORD', 'Aq@yo=uH/4' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'm93ly1obUeTn6@i{DOw_@rZ34;v_va>lWuIVF0wt8{43{&B{/sJL 61S5rvk@F:K' );
define( 'SECURE_AUTH_KEY',   '_06EW,Jxhm_b7n#]}-es>sXIf 46fd_7iAF,tm]TOmVimNxQXk)8Bk_l+P)>a<Zc' );
define( 'LOGGED_IN_KEY',     'MbglqkAy5c`(*-A=)o9BNJ79tITxmIH|<TnQ<EDaCo_qeQ8*D*4i`u8kC4##f@6o' );
define( 'NONCE_KEY',         'D1r;HVtGymhc:._lv,a1#~1mk!{]!)CL5VM0)+R?FKQMpjFv+;&Am9VN9UN:H^Ud' );
define( 'AUTH_SALT',         'jpKV`aq&dUi77+8Ur5!N $d^Bsji^o+8-Wmec@!j|3[Sf*3yy7nW0fY<XH1X^LN(' );
define( 'SECURE_AUTH_SALT',  'Luq!yBtUkgi< FO<*(z}bs2B0l8VWWP=qob,~]xy5/GP(tkXpY:1wkmkp/h4<Aiy' );
define( 'LOGGED_IN_SALT',    '{-)>i6oS=.PoA-U9@(`5+QY6,E$G;Y?,HZRX<u&t8`)qi$; >6aLzT`7MCUN;pCn' );
define( 'NONCE_SALT',        'UVpmA~j2!aXn!hGO[OX}}&:0z0`$I@|P~2g^wu:h-I&o0Xg@ka6R#3)$-t1krM$C' );
define( 'WP_CACHE_KEY_SALT', 'B!rG33yplR/qT sDKmQi.$!+FHHj]I&))L4j#@n*GP)>tBw(f5l7UjCai}Tp4=D5' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
